package com.example.a10redeem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
public class MainActivity extends AppCompatActivity {
    int Month;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = getIntent();
        intent.getIntExtra("month_putExtra",0);

    }

    public void button1(View view) {
        TextView showmonth = (TextView)findViewById(R.id.textView);
        showmonth.setText("選擇月份：1、2月");
        Month = 1;

    }

    public void button2(View view) {
        TextView showmonth = (TextView)findViewById(R.id.textView);
        showmonth.setText("選擇月份：3、4月");
        Month = 2;

    }

    public void button3(View view) {
        TextView showmonth = (TextView)findViewById(R.id.textView);
        showmonth.setText("選擇月份：5、6月");
        Month = 3;

    }

    public void button4(View view) {
        TextView showmonth = (TextView)findViewById(R.id.textView);
        showmonth.setText("選擇月份：7、8月");
        Month = 4;

    }

    public void button5(View view) {
        TextView showmonth = (TextView)findViewById(R.id.textView);
        showmonth.setText("選擇月份：9、10月");
        Month = 5;

    }

    public void button6(View view) {
        TextView showmonth = (TextView)findViewById(R.id.textView);
        showmonth.setText("選擇月份：11、12月");
        Month = 6;

    }

    public void button7(View view) {
        Intent intent;
        if(Month>0) {
            intent = new Intent(this, MainActivity2.class);
            intent.putExtra("month_putExtra", Month);
        }
        else{
            intent = new Intent(this, MainActivity.class);
        }
        startActivity(intent);
    }
}