package com.example.a10redeem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    private long[][] number = {{72863786,17527757,81548529,53893737,38976945},
                                {32656587,31792873,52185718,51183212,45600876},
                                {78678678,72983548,72345671,18441382,87076786},
                                {37686568,45879197,27836783,91834415,78068705},
                                {78662137,19759392,37893785,23144715,78605608},
                                {27867894,79316598,27863739,14824352,68070508}};
    TextView Shownumber;
    int Month;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Shownumber = (TextView)findViewById(R.id.textView3);

        Intent intent = getIntent();
        Month = intent.getIntExtra("month_putExtra",0);
        Shownumber.setText(number[Month-1][0]+"\n"+number[Month-1][1]+"\n"
                            +number[Month-1][2]+"\n"+number[Month-1][3]+"\n"
                                +number[Month-1][4]);
    }
    public void Reward(View view) {
        EditText input = (EditText)findViewById(R.id.editTextTextPersonName) ;
        Intent intent = new Intent(this,MainActivity3.class);
        double inputnumber = Integer.parseInt(input.getText().toString());

        int i=0;
        while (i<5)
        {
            int winning = 6;
            int x=8;
            while (x>=3) {
                if (((inputnumber)%(Math.pow(10,x))) == ((number[Month - 1][i])%(Math.pow(10,x)))){
                    intent.putExtra("winning_putExtra", winning);
                    x=0;
                    i=5;
                }
                else {
                    x--;
                    winning--;
                }
            }
            i++;
            intent.putExtra("winning_putExtra", winning);
        }
        startActivity(intent);
        input.setText("");
    }

    public void Select_month(View view) {
        Intent intent = new Intent(this,MainActivity.class);
        int month=0;
        intent.putExtra("month_putExtra", month);
        startActivity(intent);
    }
}