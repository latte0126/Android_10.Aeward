package com.example.a10redeem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {
    private int[]money = {0,200,1000,4000,10000,40000,200000};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        TextView winning = (TextView)findViewById(R.id.textView5);
        Intent intent = getIntent();
        int win =intent.getIntExtra("winning_putExtra",88888);
        if (win ==0)
            winning.setText("再接再厲");
        else
            winning.setText("恭喜中獎\n獎金：" + money[win]);


    }


    public void Select_number(View view) {
        Intent intent = new Intent(this,MainActivity2.class);
        startActivity(intent);
    }

    public void Select_month(View view) {
        Intent intent = new Intent(this,MainActivity.class);
        int month=0;
        intent.putExtra("month_putExtra", month);
        startActivity(intent);
    }
}